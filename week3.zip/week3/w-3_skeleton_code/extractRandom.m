function F=extractRandom(img)

% modify this function to compute a 3 dimensional image descriptor, comprising the average red green
% and blue values of the image.  This is a very crude form of global colour descriptor.  Within the function,

% compute the average red value of the image using:‐ 
red=img(:,:,1);
red=reshape(red,1,[]);
average_red=mean(red);

% compute the average green value of the image using:‐
green=img(:,:,1);
green=reshape(green,1,[]);
average_green=mean(green);

% compute the average red value of the image using:‐
blue=img(:,:,1);
blue=reshape(blue,1,[]);
average_blue=mean(blue);

%do the same for green and blue.  Concatenate these three values to form a feature vector F:‐ 
F=[average_red average_green average_blue]; 

%F=rand(1,60000);

% Returns a row [rand rand .... rand] representing an image descriptor
% computed from image 'img'

% Note img is a normalised RGB image i.e. colours range [0,1] not [0,255].

return;